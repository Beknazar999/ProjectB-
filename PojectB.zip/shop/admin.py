from django.contrib import admin
from .models import Product, Category

class ProductAdmin(admin.ModelAdmin):
    readonly_fields = ('id',)

class CategoryAdmin(admin.ModelAdmin):
    readonly_fields = ('id',)

admin.site.register(Product)
admin.site.register(Category)
