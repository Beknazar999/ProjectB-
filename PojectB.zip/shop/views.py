from django.shortcuts import render, redirect

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework import permissions
from rest_framework import viewsets
from .models import Category, Product
from .serializers import CategorySerializer, ProductSerializer
from django.shortcuts import get_object_or_404

from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic
from django.http import HttpResponse
from rest_framework import generics

from rest_framework.permissions import IsAuthenticated
from .models import Profile
from .serializers import ProfileSerializer
from django.http import Http404



class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

    def get_queryset(self):
        if 'category_pk' in self.kwargs:
            return self.queryset.filter(category_id=self.kwargs['category_pk'])
        return self.queryset


    def category_list(request):
        categories = Category.objects.all()
        return render(request, 'category_list.html', {'categories': categories})



class CategoryListApiView(APIView):
    # add permission to check if user is authenticated
    permission_classes = [permissions.AllowAny]
    

    def get(self, request, *args, **kwargs):
        # Retrieve all categories
        categories = Category.objects.all()
        serializer = CategorySerializer(categories, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    

class CategoryDetailApiView(APIView):
    # Add permission to check if user is authenticated
    permission_classes = [permissions.AllowAny]

    def get_object(self, category_id):
        '''
        Helper method to get the object with given category_id
        '''
        try:
            return Category.objects.get(id=category_id)
        except Category.DoesNotExist:
            return None

    # Retrieve a specific category
    def get(self, request, category_id, *args, **kwargs):
        '''
        Retrieves the category with given category_id
        '''
        category_instance = self.get_object(category_id)
        if not category_instance:
            return Response(
                {"res": "Category with given ID does not exist"},
                status=status.HTTP_404_NOT_FOUND
            )

        serializer = CategorySerializer(category_instance)
        response_data = serializer.data
        response_data['category_id'] = category_instance.id  # Include category ID in response
        return Response(response_data, status=status.HTTP_200_OK)

    # Update a specific category
    def put(self, request, category_id, *args, **kwargs):
        '''
        Updates the category with given category_id if exists
        '''
        category_instance = self.get_object(category_id)
        if not category_instance:
            return Response(
                {"res": "Category with given ID does not exist"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        serializer = CategorySerializer(instance=category_instance, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    # Delete a specific category
    def delete(self, request, category_id, *args, **kwargs):
        '''
        Deletes the category with given category_id if exists
        '''
        category_instance = self.get_object(category_id)
        if not category_instance:
            return Response(
                {"res": "Category with given ID does not exist"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        category_instance.delete()
        return Response(
            {"res": "Category deleted!"},
            status=status.HTTP_200_OK
        )
    

class ProductListApiView(APIView):
    def get(self, request, *args, **kwargs):
        """
        Retrieves a list of all products with their IDs.
        """
        products = Product.objects.all()
        serializer = ProductSerializer(products, many=True)
        data = serializer.data
        # Add product IDs to the response data
        for idx, product in enumerate(products):
            data[idx]['product_id'] = product.id
        return Response(data, status=status.HTTP_200_OK)

    def post(self, request, *args, **kwargs):
        """
        Creates a new product and returns its ID.
        """
        serializer = ProductSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            # Return the ID of the newly created product
            return Response({"product_id": serializer.data['id']}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    

class ProductDetailApiView(APIView):
    def get_object(self, product_id):
        '''
        Helper method to get the object with given product_id
        '''
        try:
            return Product.objects.get(id=product_id)
        except Product.DoesNotExist:
            return None

    def get(self, request, product_id):  
        '''
        Retrieves the product with the given product_id if it exists
        '''
        product = self.get_object(product_id)
        if product:
            serializer = ProductSerializer(product)
            return Response(serializer.data)
        else:
            return Response({"error": "Product not found"}, status=status.HTTP_404_NOT_FOUND)

    def put(self, request, product_id, *args, **kwargs):
        '''
        Updates the product with the given product_id if it exists
        '''
        product_instance = self.get_object(product_id)
        if not product_instance:
            return Response({"error": "Product not found"}, status=status.HTTP_404_NOT_FOUND)
        
        serializer = ProductSerializer(instance=product_instance, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, product_id, *args, **kwargs):
        '''
        Deletes the product with the given product_id if it exists
        '''
        product_instance = self.get_object(product_id)
        if not product_instance:
            return Response({"error": "Product not found"}, status=status.HTTP_404_NOT_FOUND)
        
        product_instance.delete()
        return Response({"success": "Product deleted successfully"}, status=status.HTTP_204_NO_CONTENT)

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')  # Замените 'home' на имя вашего домашнего URL-адреса
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})

class SignUpView(generic.CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy('login')
    template_name = 'registration/signup.html'

    def form_valid(self, form):
        response = super().form_valid(form)
        return HttpResponse("Вы успешно прошли регистрацию")


class ProductFilterView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request, *args, **kwargs):
        categories = Category.objects.all()
        return render(request, 'product_filter.html', {'categories': categories})


class ProductListApiView(APIView):
    def get(self, request, *args, **kwargs):
        category_id = request.GET.get('category')
        if category_id:
            products = Product.objects.filter(category_id=category_id)
        else:
            products = Product.objects.all()
        
        serializer = ProductSerializer(products, many=True)
        data = serializer.data
        for idx, product in enumerate(products):
            data[idx]['product_id'] = product.id
        return Response(data, status=status.HTTP_200_OK)
    


class ProductFilterByCategoryAPIView(generics.ListAPIView):
    serializer_class = ProductSerializer

    def get_queryset(self):
        category_id = self.kwargs['category_id']
        return Product.objects.filter(category_id=category_id)


class ProductFilterAPIView(generics.ListAPIView):
    serializer_class = ProductSerializer

    def get_queryset(self):
        queryset = Product.objects.all()

        # Фильтрация по категории
        category_id = self.kwargs.get('category_id')
        if category_id:
            queryset = queryset.filter(category_id=category_id)

        # Фильтрация по размеру
        size = self.request.query_params.get('size')
        if size:
            queryset = queryset.filter(size=size)

        # Фильтрация по цвету
        color = self.request.query_params.get('color')
        if color:
            queryset = queryset.filter(color=color)

        return queryset

class ProfileDetailView(generics.RetrieveUpdateAPIView):
    queryset = Profile.objects.all()
    serializer_class = ProfileSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        try:
            return self.request.user.profile
        except Profile.DoesNotExist:
            raise Http404("Profile does not exist")




















# from django.shortcuts import render
# from .models import Product, Category

# def product_view(request):
#     products = Product.objects.all()
#     return render(request, 'product_template.html', {'products': products})

# def category_view(request):
#     categories = Category.objects.all()
#     return render(request, 'category_template.html', {'categories': categories})


























# class CategoryViewSet(viewsets.ViewSet):
#     @action(detail=False, methods=['get'])
#     def list(self, request):
#         # Ваша логика для представления списка категорий
#         return Response("List of categories")
    






# https://blog.logrocket.com/django-rest-framework-create-api/