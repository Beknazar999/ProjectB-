from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import CategoryViewSet, ProductViewSet
from . import views   
from .views import (
    CategoryListApiView,
    CategoryDetailApiView,
    ProductListApiView,
    ProductDetailApiView
)
from django.contrib.auth import views as auth_views
from .views import SignUpView
from .views import ProductFilterByCategoryAPIView
from .views import ProfileDetailView



router = DefaultRouter()
router.register(r'categories', CategoryViewSet)
router.register(r'categories/(?P<category_pk>\d+)/products', ProductViewSet, basename='category-product')

urlpatterns = [
    path('api/v1/shop/', include(router.urls)),
    path('api/v1/shop/all', views.ProductViewSet.as_view({'get': 'list'}), name='product-all'),
    path('api/v1/shop/category', views.CategoryListApiView.as_view()),
    path('api/v1/category/<int:category_id>/', CategoryDetailApiView.as_view(), name='category-detail'),
    path('api/v1/shop/category/id/product', views.ProductListApiView.as_view()),
    path('api/v1/shop/category/product/<int:product_id>/', ProductDetailApiView.as_view(), name='product-detail'),
    path('accounts/login/', auth_views.LoginView.as_view(), name='login'),
    path('signup/', SignUpView.as_view(), name='signup'),
    path('api/v1/shop/category/<int:category_id>/products/', ProductFilterByCategoryAPIView.as_view(), name='product-filter-by-category, size, color'),
    path('api/v1/profile/', ProfileDetailView.as_view(), name='profile-detail'),
    
]
